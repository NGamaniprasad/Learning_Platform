
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

export const sendMessage = async (
  message: string, 
  history: { role: string, content: string }[]
): Promise<string> => {
  const ai = getAIClient();
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: "You are NexusAI, a professional assistant for enterprise SaaS users. Be concise, helpful, and technically accurate.",
    }
  });

  // Reconstruct history
  // Note: For Gemini chats.create, history is passed in slightly different structure normally,
  // but we can also just use generateContent for simpler stateless calls or map the history.
  const response = await chat.sendMessage({ message });
  return response.text || "No response generated.";
};

export const analyzeFile = async (fileName: string, fileContent: string): Promise<string> => {
    const ai = getAIClient();
    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze the following file named ${fileName}: \n\n ${fileContent}`
    });
    return response.text || "Could not analyze file.";
}
