
import React, { useState, useEffect } from 'react';
import { AppView, User } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import ChatInterface from './components/ChatInterface';
import FileLibrary from './components/FileLibrary';
import Subscription from './components/Subscription';
import AdminDashboard from './components/AdminDashboard';
import Auth from './components/Auth';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentView, setCurrentView] = useState<AppView>(AppView.DASHBOARD);
  const [user, setUser] = useState<User | null>(null);

  // Simulation of auth state check
  useEffect(() => {
    const storedUser = localStorage.getItem('nexus_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = (u: User) => {
    setUser(u);
    setIsAuthenticated(true);
    localStorage.setItem('nexus_user', JSON.stringify(u));
  };

  const handleLogout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('nexus_user');
  };

  if (!isAuthenticated) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <Sidebar 
        currentView={currentView} 
        setView={setCurrentView} 
        onLogout={handleLogout}
        isAdmin={user?.isAdmin || false}
      />
      
      <main className="flex-1 overflow-y-auto relative">
        <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 py-4 flex justify-between items-center">
          <h1 className="text-xl font-semibold text-slate-800 uppercase tracking-wider">
            {currentView.replace('_', ' ')}
          </h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-slate-500">{user?.email}</span>
            <div className="h-8 w-8 rounded-full bg-indigo-600 flex items-center justify-center text-white text-xs font-bold">
              {user?.email[0].toUpperCase()}
            </div>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto">
          {currentView === AppView.DASHBOARD && <Dashboard user={user!} />}
          {currentView === AppView.CHAT && <ChatInterface />}
          {currentView === AppView.FILES && <FileLibrary />}
          {currentView === AppView.BILLING && <Subscription user={user!} />}
          {currentView === AppView.ADMIN && user?.isAdmin && <AdminDashboard />}
        </div>
      </main>
    </div>
  );
};

export default App;
