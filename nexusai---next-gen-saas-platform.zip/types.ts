
export enum AppView {
  DASHBOARD = 'DASHBOARD',
  CHAT = 'CHAT',
  FILES = 'FILES',
  BILLING = 'BILLING',
  ADMIN = 'ADMIN'
}

export interface User {
  id: string;
  email: string;
  plan: 'free' | 'pro' | 'enterprise';
  isAdmin: boolean;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface FileEntry {
  id: string;
  name: string;
  size: number;
  type: string;
  uploadedAt: Date;
}
