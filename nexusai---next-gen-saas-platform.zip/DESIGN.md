
# NexusAI System Architecture

## 1. High-Level Architecture
- **Frontend**: React 18 SPA, Tailwind CSS for styling, Recharts for analytics.
- **Backend (Proposed)**: FastAPI (Python) for high-performance async processing.
- **Database**: PostgreSQL (Structured data), Redis (Caching/Sessions).
- **AI Engine**: Google Gemini (Flash 3.0 & Pro 3.0) for multi-modal reasoning.
- **Payments**: Stripe Integration.
- **Storage**: AWS S3 or Google Cloud Storage for user-uploaded files.

## 2. Database Schema (PostgreSQL)

```sql
-- Users Table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    hashed_password TEXT NOT NULL,
    subscription_plan TEXT DEFAULT 'free', -- 'free', 'pro', 'enterprise'
    stripe_customer_id TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Files Table
CREATE TABLE files (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    name TEXT NOT NULL,
    storage_url TEXT NOT NULL,
    file_type TEXT,
    size INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Chat Conversations
CREATE TABLE conversations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    title TEXT,
    last_message_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Messages
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    conversation_id UUID REFERENCES conversations(id),
    role TEXT NOT NULL, -- 'user' or 'assistant'
    content TEXT NOT NULL,
    tokens_used INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

## 3. API Design (FastAPI)

- `POST /auth/register`: Create new user.
- `POST /auth/login`: JWT authentication.
- `GET /user/profile`: Fetch subscription status.
- `POST /chat/completions`: Proxy to Gemini API with token tracking.
- `POST /files/upload`: Secure multipart upload.
- `POST /billing/create-checkout-session`: Stripe redirection.
- `GET /admin/stats`: Aggregate platform usage (Admin only).
