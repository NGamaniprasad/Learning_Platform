
import React, { useState } from 'react';
import { FileEntry } from '../types';
import { analyzeFile } from '../services/geminiService';

const FileLibrary: React.FC = () => {
  const [files, setFiles] = useState<FileEntry[]>([
    { id: '1', name: 'Q4_Report.pdf', size: 1024 * 1024 * 2.5, type: 'application/pdf', uploadedAt: new Date('2023-12-01') },
    { id: '2', name: 'User_Feedback.csv', size: 1024 * 450, type: 'text/csv', uploadedAt: new Date('2023-11-28') },
  ]);
  const [isUploading, setIsUploading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    // Simulate upload delay
    setTimeout(() => {
      const newFile: FileEntry = {
        id: Math.random().toString(),
        name: file.name,
        size: file.size,
        type: file.type,
        uploadedAt: new Date()
      };
      setFiles(prev => [newFile, ...prev]);
      setIsUploading(false);
    }, 1500);
  };

  const handleAnalyze = async (file: FileEntry) => {
      setAnalysisResult(`Analyzing ${file.name}...`);
      try {
          // In a real app, we'd fetch the file content here. 
          // Since we are simulating, we just pass dummy content.
          const res = await analyzeFile(file.name, "Simulation content of the file uploaded to NexusAI.");
          setAnalysisResult(res);
      } catch (err) {
          setAnalysisResult("Analysis failed.");
      }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-slate-800">My Files</h2>
        <div className="relative">
          <input
            type="file"
            id="file-upload"
            className="hidden"
            onChange={handleFileUpload}
            disabled={isUploading}
          />
          <label
            htmlFor="file-upload"
            className={`cursor-pointer bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-all flex items-center space-x-2 ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}
          >
            {isUploading ? (
              <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
            )}
            <span>{isUploading ? 'Uploading...' : 'Upload File'}</span>
          </label>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Name</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Size</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Uploaded At</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {files.map((file) => (
              <tr key={file.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    </div>
                    <span className="font-medium text-slate-700">{file.name}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-slate-500">
                  {(file.size / (1024 * 1024)).toFixed(2)} MB
                </td>
                <td className="px-6 py-4 text-sm text-slate-500">
                  {file.uploadedAt.toLocaleDateString()}
                </td>
                <td className="px-6 py-4">
                  <button 
                    onClick={() => handleAnalyze(file)}
                    className="text-indigo-600 hover:text-indigo-800 text-sm font-semibold"
                  >
                    AI Analyze
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {files.length === 0 && (
          <div className="p-12 text-center">
            <p className="text-slate-400">No files uploaded yet.</p>
          </div>
        )}
      </div>

      {analysisResult && (
          <div className="bg-slate-900 text-slate-100 p-6 rounded-2xl animate-fade-in shadow-xl">
              <div className="flex justify-between items-center mb-4">
                  <h4 className="font-bold flex items-center space-x-2">
                    <svg className="w-5 h-5 text-indigo-400" fill="currentColor" viewBox="0 0 20 20"><path d="M11 3a1 1 0 10-2 0v1a1 1 0 102 0V3zM15.657 5.757a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM5.05 6.464A1 1 0 106.464 5.05l-.707-.707a1 1 0 00-1.414 1.414l.707.707zM5 10a1 1 0 01-1 1H3a1 1 0 110-2h1a1 1 0 011 1zM8 16v-1a1 1 0 112 0v1a1 1 0 11-2 0zM13 16v-1a1 1 0 112 0v1a1 1 0 11-2 0zM15.657 14.243a1 1 0 010 1.414l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 0zM6.464 14.95a1 1 0 11-1.414 1.414l-.707-.707a1 1 0 011.414-1.414l.707.707z"/></svg>
                    <span>NexusAI Analysis</span>
                  </h4>
                  <button onClick={() => setAnalysisResult(null)} className="text-slate-400 hover:text-white">&times;</button>
              </div>
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{analysisResult}</p>
          </div>
      )}
    </div>
  );
};

export default FileLibrary;
