
import React from 'react';
import { User } from '../types';

const plans = [
  { name: 'Free', price: '0', features: ['100 AI Messages / mo', '500MB Storage', 'Community Support'], isCurrent: true },
  { name: 'Pro', price: '29', features: ['Unlimited Messages', '10GB Storage', 'Email Support', 'Priority API Access'], isCurrent: false },
  { name: 'Enterprise', price: '99', features: ['Custom Models', '1TB Storage', '24/7 Dedicated Support', 'SLA Guarantee'], isCurrent: false },
];

const Subscription: React.FC<{ user: User }> = ({ user }) => {
  return (
    <div className="space-y-8">
      <div className="bg-indigo-600 rounded-2xl p-8 text-white flex flex-col md:flex-row items-center justify-between shadow-xl shadow-indigo-600/20">
        <div>
          <h2 className="text-2xl font-bold mb-2">Upgrade to Pro</h2>
          <p className="text-indigo-100 max-w-md">Get unlimited access to advanced models and higher storage limits for your team.</p>
        </div>
        <button className="mt-6 md:mt-0 bg-white text-indigo-600 px-8 py-3 rounded-xl font-bold hover:bg-indigo-50 transition-colors shadow-lg shadow-black/10">
          Get Started
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan) => (
          <div key={plan.name} className={`bg-white p-8 rounded-2xl border ${user.plan.toLowerCase() === plan.name.toLowerCase() ? 'border-indigo-500 ring-4 ring-indigo-500/10' : 'border-slate-200'} shadow-sm flex flex-col`}>
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-800">{plan.name}</h3>
              <div className="mt-4 flex items-baseline">
                <span className="text-4xl font-bold text-slate-900">${plan.price}</span>
                <span className="text-slate-500 ml-1">/ month</span>
              </div>
            </div>

            <ul className="flex-1 space-y-4 mb-8">
              {plan.features.map((feature) => (
                <li key={feature} className="flex items-center space-x-3 text-sm text-slate-600">
                  <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>

            <button className={`w-full py-3 rounded-xl font-bold transition-all ${
              user.plan.toLowerCase() === plan.name.toLowerCase()
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
              : 'bg-slate-900 text-white hover:bg-slate-800 shadow-lg shadow-slate-900/10'
            }`}>
              {user.plan.toLowerCase() === plan.name.toLowerCase() ? 'Current Plan' : 'Select Plan'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Subscription;
