
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Chatbot from './components/Chatbot';
import PDFAnalyzer from './components/PDFAnalyzer';
import AITutor from './components/AITutor';
import { AppView } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>('chatbot');

  const renderView = () => {
    switch (currentView) {
      case 'chatbot':
        return <Chatbot />;
      case 'pdf-analyzer':
        return <PDFAnalyzer />;
      case 'ai-tutor':
        return <AITutor />;
      case 'settings':
        return (
          <div className="p-12 max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold mb-6">Settings</h2>
            <div className="space-y-8">
              <div className="p-6 bg-white border rounded-2xl">
                <h3 className="font-bold text-lg mb-2">API Configuration</h3>
                <p className="text-slate-500 mb-4">Gemini API key is currently managed via environment variables.</p>
                <div className="flex items-center gap-2 text-green-600 bg-green-50 px-3 py-2 rounded-lg text-sm font-medium">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                  API Status: Connected
                </div>
              </div>

              <div className="p-6 bg-white border rounded-2xl">
                <h3 className="font-bold text-lg mb-2">Personalization</h3>
                <p className="text-slate-500 mb-4">Coming soon: Sync your learning history across devices.</p>
                <button className="px-4 py-2 bg-slate-100 text-slate-400 rounded-lg cursor-not-allowed font-medium">
                  Sign In to Sync
                </button>
              </div>
            </div>
          </div>
        );
      default:
        return <Chatbot />;
    }
  };

  return (
    <div className="flex h-screen w-full bg-slate-50 overflow-hidden">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {/* Subtle decorative background elements */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-blue-100/30 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-[-5%] left-[10%] w-[300px] h-[300px] bg-slate-200/50 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="relative flex-1 flex flex-col h-full">
          {renderView()}
        </div>
      </main>
    </div>
  );
};

export default App;
