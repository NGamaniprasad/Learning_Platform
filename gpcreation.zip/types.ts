
export type MessageRole = 'user' | 'model' | 'system';

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
  attachments?: {
    name: string;
    type: string;
    data?: string;
  }[];
}

export type AppView = 'chatbot' | 'pdf-analyzer' | 'ai-tutor' | 'settings';

export interface TutorTopic {
  id: string;
  title: string;
  description: string;
}

export interface PDFAnalysis {
  fileName: string;
  summary: string;
  keyPoints: string[];
}
