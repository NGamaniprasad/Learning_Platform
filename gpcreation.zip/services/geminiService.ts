
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { MessageRole, ChatMessage } from "../types";

const MODEL_FLASH = 'gemini-3-flash-preview';
const MODEL_PRO = 'gemini-3-pro-preview';

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async chat(messages: ChatMessage[], systemInstruction?: string) {
    const contents = messages.map(m => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }]
    }));

    const response = await this.ai.models.generateContent({
      model: MODEL_FLASH,
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    return response.text;
  }

  async *streamChat(messages: ChatMessage[], systemInstruction?: string) {
    const contents = messages.map(m => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }]
    }));

    const result = await this.ai.models.generateContentStream({
      model: MODEL_FLASH,
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    for await (const chunk of result) {
      yield (chunk as GenerateContentResponse).text;
    }
  }

  async analyzePDF(text: string, fileName: string) {
    const response = await this.ai.models.generateContent({
      model: MODEL_PRO,
      contents: `Please analyze the following document content from ${fileName} and provide a concise summary followed by key points. \n\nContent: ${text.substring(0, 30000)}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            keyPoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["summary", "keyPoints"]
        }
      }
    });

    return JSON.parse(response.text || '{}');
  }

  async generateLearningPath(topic: string) {
    const response = await this.ai.models.generateContent({
      model: MODEL_PRO,
      contents: `Act as a professional tutor. Create a detailed learning path for the topic: "${topic}". Include 5 progressive steps and a brief exercise for each.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            steps: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  stepNumber: { type: Type.NUMBER },
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  exercise: { type: Type.STRING }
                },
                required: ["stepNumber", "title", "description", "exercise"]
              }
            }
          },
          required: ["title", "steps"]
        }
      }
    });

    return JSON.parse(response.text || '{}');
  }
}

export const gemini = new GeminiService();
