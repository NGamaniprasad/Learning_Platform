
import React, { useState } from 'react';
import { gemini } from '../services/geminiService';
import { Search, BookOpen, ChevronRight, GraduationCap, Loader2, Star } from 'lucide-react';

interface Step {
  stepNumber: number;
  title: string;
  description: string;
  exercise: string;
}

const AITutor: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [learningPath, setLearningPath] = useState<{title: string; steps: Step[]} | null>(null);

  const generatePath = async () => {
    if (!topic.trim()) return;
    setIsGenerating(true);
    setLearningPath(null);

    try {
      const result = await gemini.generateLearningPath(topic);
      setLearningPath(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const popularTopics = ["React Development", "Quantum Physics", "Digital Marketing", "Machine Learning"];

  return (
    <div className="max-w-4xl mx-auto w-full p-8 h-full overflow-y-auto">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-600/20">
          <GraduationCap size={28} />
        </div>
        <div>
          <h2 className="text-2xl font-bold">AI Personalized Tutor</h2>
          <p className="text-slate-500">Transform any complex topic into a manageable learning journey.</p>
        </div>
      </div>

      <div className="relative mb-10 group">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-slate-400 group-focus-within:text-blue-600 transition-colors">
          <Search size={20} />
        </div>
        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="What do you want to learn today?"
          className="w-full bg-white border-2 border-slate-100 rounded-2xl pl-12 pr-32 py-4 focus:outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-600/5 transition-all shadow-sm text-lg"
          onKeyDown={(e) => e.key === 'Enter' && generatePath()}
        />
        <button
          onClick={generatePath}
          disabled={!topic.trim() || isGenerating}
          className="absolute right-2 inset-y-2 px-6 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 disabled:opacity-50 transition-all shadow-md"
        >
          {isGenerating ? <Loader2 className="animate-spin" /> : 'Create Path'}
        </button>
      </div>

      {!learningPath && !isGenerating && (
        <div className="space-y-6">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">Popular Learning Paths</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {popularTopics.map((t) => (
              <button
                key={t}
                onClick={() => {
                  setTopic(t);
                  // We could auto-trigger generatePath here if desired
                }}
                className="p-4 bg-white border border-slate-100 rounded-2xl text-left hover:border-blue-600 hover:shadow-md transition-all group"
              >
                <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center mb-3 group-hover:bg-blue-50 transition-colors">
                  <BookOpen size={20} className="text-slate-400 group-hover:text-blue-600" />
                </div>
                <p className="font-semibold text-slate-800">{t}</p>
                <ChevronRight size={16} className="text-slate-300 mt-2 group-hover:translate-x-1 transition-transform" />
              </button>
            ))}
          </div>
        </div>
      )}

      {isGenerating && (
        <div className="flex flex-col items-center justify-center py-20 text-slate-400">
          <Loader2 size={48} className="animate-spin text-blue-600 mb-4" />
          <p className="text-lg font-medium animate-pulse">Crafting your curriculum...</p>
        </div>
      )}

      {learningPath && (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-bold text-slate-900">{learningPath.title}</h3>
            <div className="flex items-center gap-2 bg-yellow-50 text-yellow-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
              <Star size={14} fill="currentColor" />
              Custom Path
            </div>
          </div>

          <div className="space-y-6">
            {learningPath.steps.map((step) => (
              <div key={step.stepNumber} className="relative pl-12 group">
                {/* Connector Line */}
                {step.stepNumber < learningPath.steps.length && (
                  <div className="absolute left-[23px] top-10 bottom-0 w-0.5 bg-slate-100 group-hover:bg-blue-100 transition-colors"></div>
                )}
                
                {/* Step Circle */}
                <div className="absolute left-0 top-0 w-12 h-12 bg-white border-4 border-slate-50 rounded-full flex items-center justify-center font-bold text-slate-400 z-10 group-hover:border-blue-50 group-hover:text-blue-600 transition-all shadow-sm">
                  {step.stepNumber}
                </div>

                <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm group-hover:shadow-md transition-all group-hover:border-blue-100">
                  <h4 className="text-xl font-bold text-slate-800 mb-2">{step.title}</h4>
                  <p className="text-slate-600 leading-relaxed mb-4">{step.description}</p>
                  
                  <div className="bg-blue-50/50 p-4 rounded-2xl">
                    <p className="text-xs font-bold uppercase tracking-widest text-blue-600 mb-2">Practice Challenge</p>
                    <p className="text-slate-700 italic">{step.exercise}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-8 text-center">
            <p className="text-slate-400 text-sm mb-4">Mastered this topic? Try another one.</p>
            <button 
              onClick={() => { setLearningPath(null); setTopic(''); }}
              className="text-blue-600 font-bold hover:underline"
            >
              Back to search
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AITutor;
