
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { gemini } from '../services/geminiService';
import { Send, User, Bot, Loader2 } from 'lucide-react';

const Chatbot: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const modelMsgId = (Date.now() + 1).toString();
      const initialModelMsg: ChatMessage = {
        id: modelMsgId,
        role: 'model',
        content: '',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, initialModelMsg]);

      let fullResponse = '';
      const stream = gemini.streamChat([...messages, userMsg], "You are a helpful AI assistant created by GpCreation.");
      
      for await (const chunk of stream) {
        fullResponse += chunk;
        setMessages(prev => prev.map(m => 
          m.id === modelMsgId ? { ...m, content: fullResponse } : m
        ));
      }
    } catch (error) {
      console.error('Chat error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto w-full">
      <div className="p-6 border-b bg-white/50 backdrop-blur-sm sticky top-0 z-10">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Bot className="text-blue-600" />
          AI Chat Assistant
        </h2>
        <p className="text-sm text-slate-500">Ask me anything, I'm here to help.</p>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6"
      >
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50">
            <div className="bg-slate-100 p-6 rounded-full">
              <MessageSquare size={48} className="text-slate-400" />
            </div>
            <div>
              <p className="text-lg font-medium">No messages yet</p>
              <p className="text-sm">Start a conversation by typing below.</p>
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div 
            key={msg.id}
            className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              msg.role === 'user' ? 'bg-blue-600' : 'bg-slate-200'
            }`}>
              {msg.role === 'user' ? <User size={16} className="text-white" /> : <Bot size={16} className="text-slate-600" />}
            </div>
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
              msg.role === 'user' 
                ? 'bg-blue-600 text-white rounded-tr-none' 
                : 'bg-white border text-slate-800 rounded-tl-none'
            }`}>
              <p className="whitespace-pre-wrap leading-relaxed">{msg.content || (isLoading && msg.role === 'model' && !msg.content ? '...' : '')}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="p-6 bg-white border-t">
        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Ask me anything..."
            className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-4 pr-12 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none min-h-[52px] max-h-32"
            rows={1}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className={`absolute right-2 bottom-2 p-2 rounded-xl transition-colors ${
              !input.trim() || isLoading ? 'text-slate-400' : 'text-blue-600 hover:bg-blue-50'
            }`}
          >
            {isLoading ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} />}
          </button>
        </div>
      </div>
    </div>
  );
};

// Re-using MessageSquare icon locally for the empty state
import { MessageSquare } from 'lucide-react';

export default Chatbot;
