
export enum LessonType {
  VIDEO = 'VIDEO',
  QUIZ = 'QUIZ',
  READING = 'READING'
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface Lesson {
  id: string;
  title: string;
  type: LessonType;
  duration: string;
  videoUrl?: string;
  content?: string;
  quiz?: QuizQuestion[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: string;
  thumbnail: string;
  category: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  lessons: Lesson[];
}

export interface UserProgress {
  courseId: string;
  completedLessons: string[];
  lastLessonId: string;
  quizScores: Record<string, number>;
  certificateIssued: boolean;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}
