
import { Course, LessonType } from './types';

export const MOCK_COURSES: Course[] = [
  {
    id: 'c1',
    title: 'Modern Web Development with React',
    description: 'Master the fundamentals of React 18, Hooks, and the modern ecosystem.',
    instructor: 'Sarah Jenkins',
    category: 'Development',
    level: 'Intermediate',
    thumbnail: 'https://picsum.photos/seed/react/800/450',
    lessons: [
      {
        id: 'l1',
        title: 'Introduction to React 18',
        type: LessonType.VIDEO,
        duration: '10:15',
        videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
      },
      {
        id: 'l2',
        title: 'State Management Fundamentals',
        type: LessonType.VIDEO,
        duration: '15:30',
        videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4'
      },
      {
        id: 'l3',
        title: 'React Fundamentals Quiz',
        type: LessonType.QUIZ,
        duration: '5:00',
        quiz: [
          {
            id: 'q1',
            question: 'What is the virtual DOM?',
            options: ['A full copy of the real DOM', 'A lightweight representation of the real DOM', 'A browser extension'],
            correctAnswer: 1
          },
          {
            id: 'q2',
            question: 'Which hook is used for side effects?',
            options: ['useState', 'useContext', 'useEffect'],
            correctAnswer: 2
          }
        ]
      }
    ]
  },
  {
    id: 'c2',
    title: 'Advanced AI Prompt Engineering',
    description: 'Learn how to unlock the full potential of LLMs through advanced prompting.',
    instructor: 'Dr. Michael Chen',
    category: 'AI',
    level: 'Advanced',
    thumbnail: 'https://picsum.photos/seed/ai/800/450',
    lessons: [
      {
        id: 'l4',
        title: 'The Mechanics of LLMs',
        type: LessonType.VIDEO,
        duration: '12:45',
        videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
      },
      {
        id: 'l5',
        title: 'Chain-of-Thought Prompting',
        type: LessonType.VIDEO,
        duration: '20:00',
        videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4'
      }
    ]
  }
];
