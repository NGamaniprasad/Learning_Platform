
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import { MOCK_COURSES } from './constants';
import { UserProgress, LessonType, Course } from './types';
import VideoPlayer from './components/VideoPlayer';
import AiTutor from './components/AiTutor';
import QuizView from './components/QuizView';
import Certificate from './components/Certificate';

// --- Home Component ---
const HomePage: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <header className="mb-12 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold text-slate-900 mb-4 tracking-tight">
          Level up with <span className="text-indigo-600">Lumina Learn</span>
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto">
          World-class educational content powered by advanced AI tutoring for a personalized learning experience.
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {MOCK_COURSES.map(course => (
          <Link to={`/course/${course.id}`} key={course.id} className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-slate-100">
            <div className="relative aspect-video overflow-hidden">
              <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-indigo-600 uppercase">
                {course.category}
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-lg font-bold mb-2 text-slate-800 group-hover:text-indigo-600 transition-colors">{course.title}</h3>
              <p className="text-slate-500 text-sm mb-4 line-clamp-2">{course.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold px-2 py-1 bg-slate-100 text-slate-600 rounded">{course.level}</span>
                <span className="text-indigo-600 text-sm font-bold flex items-center gap-1">
                  View Course <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" /></svg>
                </span>
              </div>
            </div>
          </Link>
        ))}
      </section>
    </div>
  );
};

// --- Course Detail Component ---
const CourseDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const course = MOCK_COURSES.find(c => c.id === id);
  if (!course) return <div>Course not found</div>;

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2">
          <h1 className="text-4xl font-bold mb-4 text-slate-900">{course.title}</h1>
          <p className="text-lg text-slate-600 mb-8">{course.description}</p>
          
          <h3 className="text-xl font-bold mb-4">Syllabus</h3>
          <div className="space-y-4">
            {course.lessons.map((lesson, idx) => (
              <div key={lesson.id} className="flex items-center gap-4 p-4 bg-white rounded-xl border border-slate-200">
                <div className="w-10 h-10 flex-shrink-0 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 font-bold">
                  {idx + 1}
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-slate-800">{lesson.title}</h4>
                  <p className="text-xs text-slate-400 flex items-center gap-2">
                    {lesson.type === LessonType.VIDEO ? (
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" /></svg>
                    ) : (
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" /><path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clipRule="evenodd" /></svg>
                    )}
                    {lesson.duration}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-100 h-fit sticky top-24">
          <img src={course.thumbnail} alt="" className="w-full rounded-xl mb-6" />
          <p className="text-3xl font-bold mb-4">Free <span className="text-slate-400 line-through text-lg font-normal ml-2">$99.99</span></p>
          <Link to={`/learn/${course.id}/${course.lessons[0].id}`} className="block w-full text-center py-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-100 mb-4 transition-all">
            Start Learning Now
          </Link>
          <ul className="space-y-3 text-sm text-slate-600">
            <li className="flex items-center gap-2"><svg className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg> Certificate of completion</li>
            <li className="flex items-center gap-2"><svg className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg> AI Personal Tutor</li>
            <li className="flex items-center gap-2"><svg className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg> Interactive Quizzes</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

// --- Learning View Component ---
const LearningView: React.FC = () => {
  const { courseId, lessonId } = useParams<{ courseId: string; lessonId: string }>();
  const navigate = useNavigate();
  const course = MOCK_COURSES.find(c => c.id === courseId);
  const lesson = course?.lessons.find(l => l.id === lessonId);
  
  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem(`progress_${courseId}`);
    return saved ? JSON.parse(saved) : { courseId, completedLessons: [], lastLessonId: lessonId, quizScores: {}, certificateIssued: false };
  });

  useEffect(() => {
    localStorage.setItem(`progress_${courseId}`, JSON.stringify(progress));
  }, [progress, courseId]);

  if (!course || !lesson) return <div>Content not found</div>;

  const handleLessonComplete = () => {
    if (!progress.completedLessons.includes(lesson.id)) {
      setProgress(prev => ({
        ...prev,
        completedLessons: [...prev.completedLessons, lesson.id]
      }));
    }
  };

  const handleQuizComplete = (score: number) => {
    setProgress(prev => ({
      ...prev,
      completedLessons: [...prev.completedLessons, lesson.id],
      quizScores: { ...prev.quizScores, [lesson.id]: score }
    }));
  };

  const isAllComplete = progress.completedLessons.length === course.lessons.length;

  return (
    <div className="flex flex-col lg:flex-row h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar Navigation */}
      <aside className="w-full lg:w-80 flex-shrink-0 bg-white border-r border-slate-200 overflow-y-auto hidden lg:flex flex-col">
        <div className="p-6 border-b">
          <Link to="/" className="text-xl font-bold text-indigo-600 mb-2 block">Lumina Learn</Link>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-4">
            <div className="bg-indigo-600 h-full transition-all" style={{ width: `${(progress.completedLessons.length / course.lessons.length) * 100}%` }}></div>
          </div>
          <p className="text-[10px] uppercase font-bold text-slate-400 mt-2 tracking-widest">{progress.completedLessons.length} / {course.lessons.length} LESSONS DONE</p>
        </div>
        <div className="flex-1">
          {course.lessons.map((l, idx) => (
            <Link
              key={l.id}
              to={`/learn/${course.id}/${l.id}`}
              className={`flex items-center gap-3 p-4 border-b border-slate-50 hover:bg-slate-50 transition-colors ${l.id === lesson.id ? 'bg-indigo-50 border-r-4 border-r-indigo-600' : ''}`}
            >
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                progress.completedLessons.includes(l.id) ? 'bg-green-100 text-green-600' : 'bg-slate-100 text-slate-400'
              }`}>
                {progress.completedLessons.includes(l.id) ? '✓' : idx + 1}
              </div>
              <span className={`text-sm font-medium ${l.id === lesson.id ? 'text-indigo-800' : 'text-slate-600'}`}>{l.title}</span>
            </Link>
          ))}
        </div>
        {isAllComplete && (
          <Link to={`/certificate/${course.id}`} className="m-4 p-4 bg-indigo-600 text-white rounded-xl text-center font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200">
            View Certificate
          </Link>
        )}
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="mb-8 flex items-center justify-between">
            <h1 className="text-2xl font-bold text-slate-800">{lesson.title}</h1>
            <Link to="/" className="lg:hidden p-2 text-slate-400 hover:text-slate-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            </Link>
          </div>

          <div className="mb-8">
            {lesson.type === LessonType.VIDEO && lesson.videoUrl && (
              <VideoPlayer url={lesson.videoUrl} onProgress={() => {}} onComplete={handleLessonComplete} />
            )}
            {lesson.type === LessonType.QUIZ && lesson.quiz && (
              <QuizView questions={lesson.quiz} onComplete={handleQuizComplete} />
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="text-lg font-bold mb-4">Lesson Resources</h3>
                <p className="text-slate-600 mb-6">
                  {lesson.content || "Download the supplementary materials for this lesson to follow along with the instructor. These resources include source code, cheat sheets, and practice exercises."}
                </p>
                <div className="flex flex-wrap gap-4">
                  <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-sm font-medium">
                    <svg className="w-4 h-4 text-red-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h3a1 1 0 100-2H7z" clipRule="evenodd" /></svg>
                    Notes.pdf
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-sm font-medium">
                    <svg className="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                    SourceCode.zip
                  </button>
                </div>
              </div>
            </div>
            
            <div className="md:col-span-1">
              <AiTutor currentLesson={lesson.title} courseContext={course.description} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

// --- Certificate Wrapper ---
const CertificateView: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const course = MOCK_COURSES.find(c => c.id === courseId);
  if (!course) return <div>Course not found</div>;

  return (
    <div className="min-h-screen bg-slate-900 py-12 px-4 flex flex-col items-center justify-center">
      <div className="mb-8">
        <Link to="/" className="text-white flex items-center gap-2 hover:text-indigo-400 transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
          Back to Courses
        </Link>
      </div>
      <Certificate 
        userName="Avery Smith" 
        courseTitle={course.title} 
        date={new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })} 
      />
      <div className="mt-8 flex gap-4">
        <button onClick={() => window.print()} className="px-6 py-3 bg-white text-slate-900 font-bold rounded-xl hover:bg-slate-100 transition-all flex items-center gap-2">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
          Print PDF
        </button>
        <button className="px-6 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all flex items-center gap-2">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>
          Share Achievement
        </button>
      </div>
    </div>
  );
};

// --- Main App ---
const Navbar: React.FC = () => (
  <nav className="bg-white border-b border-slate-100 sticky top-0 z-50">
    <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
      <Link to="/" className="flex items-center gap-2">
        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path d="M10.394 2.827a1 1 0 00-.788 0l-7 3a1 1 0 000 1.846l7 3a1 1 0 00.788 0l7-3a1 1 0 000-1.846l-7-3zM3.108 11.033a1 1 0 00-.414 1.342l3 6a1 1 0 001.611 1.052l.965-1.206a1 1 0 011.46 0l.965 1.206a1 1 0 001.611-1.052l3-6a1 1 0 00-1.751-.966l-2.433 4.867a1 1 0 01-1.46 0l-2.433-4.867a1 1 0 00-1.342-.414z" /></svg>
        </div>
        <span className="text-xl font-extrabold text-slate-800 tracking-tight">Lumina Learn</span>
      </Link>
      <div className="flex items-center gap-6">
        <Link to="/" className="text-sm font-semibold text-slate-600 hover:text-indigo-600">Browse Courses</Link>
        <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 cursor-pointer overflow-hidden border-2 border-transparent hover:border-indigo-600 transition-all">
          <img src="https://picsum.photos/seed/user/100/100" alt="Avatar" />
        </div>
      </div>
    </div>
  </nav>
);

const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen bg-slate-50">
        <Routes>
          <Route path="/" element={<><Navbar /><HomePage /></>} />
          <Route path="/course/:id" element={<><Navbar /><CourseDetail /></>} />
          <Route path="/learn/:courseId/:lessonId" element={<LearningView />} />
          <Route path="/certificate/:courseId" element={<CertificateView />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
