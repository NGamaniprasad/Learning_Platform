
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from "../types";

export const getAiTutorResponse = async (
  history: ChatMessage[],
  currentLesson: string,
  courseContext: string
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const formattedHistory = history.map(msg => ({
    role: msg.role === 'user' ? 'user' : 'model',
    parts: [{ text: msg.content }]
  }));

  const systemInstruction = `
    You are an AI Tutor for the "Lumina Learn" LMS platform.
    The student is currently watching: ${currentLesson}.
    Course context: ${courseContext}.
    Your goal is to explain concepts clearly, provide examples, and answer questions concisely.
    Keep your tone encouraging and academic but accessible.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: history.length > 0 
        ? { parts: [{ text: history[history.length - 1].content }] } 
        : { parts: [{ text: "Hello, I need help with this lesson." }] },
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    return response.text || "I'm sorry, I couldn't process that. Please try again.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The AI Tutor is currently unavailable. Please check your connection.";
  }
};
