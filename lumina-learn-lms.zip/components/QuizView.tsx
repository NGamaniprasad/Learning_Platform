
import React, { useState } from 'react';
import { QuizQuestion } from '../types';

interface QuizViewProps {
  questions: QuizQuestion[];
  onComplete: (score: number) => void;
}

const QuizView: React.FC<QuizViewProps> = ({ questions, onComplete }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selected, setSelected] = useState<number | null>(null);

  const handleNext = () => {
    if (selected === null) return;
    
    const newAnswers = [...answers, selected];
    if (currentIdx < questions.length - 1) {
      setAnswers(newAnswers);
      setCurrentIdx(currentIdx + 1);
      setSelected(null);
    } else {
      const score = newAnswers.reduce((acc, ans, i) => acc + (ans === questions[i].correctAnswer ? 1 : 0), 0);
      onComplete((score / questions.length) * 100);
    }
  };

  const question = questions[currentIdx];

  return (
    <div className="bg-white p-8 rounded-2xl shadow-lg max-w-2xl mx-auto border border-slate-100">
      <div className="mb-6 flex justify-between items-center">
        <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">Question {currentIdx + 1} of {questions.length}</span>
        <div className="w-32 h-2 bg-slate-100 rounded-full overflow-hidden">
          <div className="bg-indigo-600 h-full transition-all" style={{ width: `${((currentIdx + 1) / questions.length) * 100}%` }}></div>
        </div>
      </div>
      
      <h2 className="text-xl font-bold mb-6 text-slate-800">{question.question}</h2>
      
      <div className="space-y-3 mb-8">
        {question.options.map((opt, i) => (
          <button
            key={i}
            onClick={() => setSelected(i)}
            className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
              selected === i 
                ? 'border-indigo-600 bg-indigo-50 text-indigo-800' 
                : 'border-slate-100 hover:border-slate-200 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                selected === i ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-600'
              }`}>
                {String.fromCharCode(65 + i)}
              </span>
              {opt}
            </div>
          </button>
        ))}
      </div>
      
      <button
        onClick={handleNext}
        disabled={selected === null}
        className="w-full py-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 disabled:opacity-50 shadow-lg shadow-indigo-100 transition-all"
      >
        {currentIdx === questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
      </button>
    </div>
  );
};

export default QuizView;
