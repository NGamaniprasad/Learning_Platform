
import React from 'react';

interface CertificateProps {
  userName: string;
  courseTitle: string;
  date: string;
}

const Certificate: React.FC<CertificateProps> = ({ userName, courseTitle, date }) => {
  return (
    <div className="p-8 bg-white max-w-4xl mx-auto border-[16px] border-indigo-600/10 shadow-2xl relative overflow-hidden">
      <div className="border-[2px] border-indigo-600/20 p-12 text-center relative z-10">
        <div className="absolute top-0 left-0 w-32 h-32 border-t-4 border-l-4 border-indigo-600 opacity-20"></div>
        <div className="absolute bottom-0 right-0 w-32 h-32 border-b-4 border-r-4 border-indigo-600 opacity-20"></div>
        
        <div className="mb-8">
          <div className="w-20 h-20 bg-indigo-600 rounded-full mx-auto flex items-center justify-center text-white mb-4">
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 14l9-5-9-5-9 5 9 5z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" /></svg>
          </div>
          <h1 className="text-4xl font-serif font-bold text-slate-800 uppercase tracking-widest">Certificate of Excellence</h1>
          <p className="text-slate-500 mt-2 font-medium tracking-widest uppercase text-xs">This verifies that</p>
        </div>

        <div className="mb-10">
          <h2 className="text-5xl font-serif text-indigo-700 italic border-b-2 border-slate-100 pb-4 inline-block px-12">{userName}</h2>
        </div>

        <div className="mb-12">
          <p className="text-slate-500 mb-2">has successfully completed the comprehensive course</p>
          <h3 className="text-2xl font-bold text-slate-800">{courseTitle}</h3>
        </div>

        <div className="flex justify-between items-end mt-16 px-12">
          <div className="text-center">
            <div className="w-40 border-b border-slate-300 mb-2"></div>
            <p className="text-xs text-slate-400">Course Instructor</p>
          </div>
          <div className="text-center">
            <p className="text-indigo-600 font-bold mb-1">{date}</p>
            <p className="text-xs text-slate-400">Date Issued</p>
          </div>
          <div className="text-center">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=60x60&data=verified-lumina-learn" alt="Verify" className="mx-auto mb-2 opacity-30" />
            <p className="text-xs text-slate-400">Verify Online</p>
          </div>
        </div>
      </div>
      {/* Decorative blobs */}
      <div className="absolute top-[-20%] right-[-10%] w-64 h-64 bg-indigo-50 rounded-full blur-3xl z-0"></div>
      <div className="absolute bottom-[-20%] left-[-10%] w-64 h-64 bg-slate-100 rounded-full blur-3xl z-0"></div>
    </div>
  );
};

export default Certificate;
