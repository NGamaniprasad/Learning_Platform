
import React, { useRef, useEffect } from 'react';

interface VideoPlayerProps {
  url: string;
  onProgress: (percent: number) => void;
  onComplete: () => void;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ url, onProgress, onComplete }) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const progress = (videoRef.current.currentTime / videoRef.current.duration) * 100;
      onProgress(progress);
      if (progress > 95) {
        onComplete();
      }
    }
  };

  return (
    <div className="relative aspect-video bg-black rounded-xl overflow-hidden shadow-2xl">
      <video
        ref={videoRef}
        src={url}
        className="w-full h-full"
        controls
        onTimeUpdate={handleTimeUpdate}
      />
    </div>
  );
};

export default VideoPlayer;
