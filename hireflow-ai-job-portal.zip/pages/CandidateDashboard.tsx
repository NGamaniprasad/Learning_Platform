
import React from 'react';
import { User, UserRole } from '../types';
import { Settings, FileText, Bell, Briefcase, ChevronRight, PieChart } from 'lucide-react';
import { MOCK_JOBS } from '../constants';

interface Props {
  user: User | null;
}

const CandidateDashboard: React.FC<Props> = ({ user }) => {
  if (!user || user.role !== UserRole.CANDIDATE) {
    return <div className="p-20 text-center">Unauthorized</div>;
  }

  return (
    <div className="bg-gray-50 min-h-screen py-8 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between mb-10 gap-6">
          <div className="flex items-center space-x-6">
            <div className="relative">
              <img src={user.avatar} alt={user.name} className="w-24 h-24 rounded-3xl border-4 border-white shadow-sm" />
              <div className="absolute -bottom-2 -right-2 bg-indigo-600 text-white p-2 rounded-xl shadow-lg">
                <Settings size={16} />
              </div>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user.name.split(' ')[0]}!</h1>
              <p className="text-gray-500 font-medium">Your profile is 85% complete. Finish it to get 2x more views.</p>
            </div>
          </div>
          <div className="flex space-x-3">
            <button className="px-5 py-2.5 bg-white border border-gray-200 rounded-xl text-gray-700 font-bold hover:bg-gray-50 transition-colors flex items-center">
              <FileText size={18} className="mr-2" />
              Edit Profile
            </button>
            <button className="p-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all">
              <Bell size={20} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Column */}
          <div className="lg:col-span-2 space-y-8">
            <section>
              <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                <Briefcase size={20} className="mr-2 text-indigo-600" />
                Active Applications
              </h2>
              <div className="space-y-4">
                {MOCK_JOBS.slice(0, 3).map((job, idx) => (
                  <div key={job.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <img src={job.companyLogo} alt={job.companyName} className="w-12 h-12 rounded-xl" />
                        <div>
                          <h4 className="font-bold text-gray-900">{job.title}</h4>
                          <p className="text-sm text-gray-500">{job.companyName}</p>
                        </div>
                      </div>
                      <span className={`px-4 py-1.5 rounded-full text-xs font-bold ${
                        idx === 0 ? 'bg-indigo-50 text-indigo-600' :
                        idx === 1 ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600'
                      }`}>
                        {idx === 0 ? 'Applied' : idx === 1 ? 'Under Review' : 'Interview Scheduled'}
                      </span>
                    </div>
                    <div className="mt-4 pt-4 border-t border-gray-50 flex items-center justify-between text-sm">
                      <span className="text-gray-400">Applied 3 days ago</span>
                      <button className="text-indigo-600 font-bold hover:underline">View Application</button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            <section className="bg-indigo-600 rounded-3xl p-8 text-white shadow-xl shadow-indigo-200">
              <h3 className="text-lg font-bold mb-2 flex items-center">
                <PieChart size={20} className="mr-2" />
                Profile Insights
              </h3>
              <p className="text-indigo-100 text-sm mb-6">How you compare to other candidates in your field.</p>
              
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between text-xs font-bold uppercase tracking-wider mb-2">
                    <span>Profile Views</span>
                    <span>248</span>
                  </div>
                  <div className="w-full h-2 bg-indigo-500 rounded-full overflow-hidden">
                    <div className="h-full bg-white w-2/3"></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs font-bold uppercase tracking-wider mb-2">
                    <span>Search Appearances</span>
                    <span>1.2k</span>
                  </div>
                  <div className="w-full h-2 bg-indigo-500 rounded-full overflow-hidden">
                    <div className="h-full bg-white w-3/4"></div>
                  </div>
                </div>
              </div>

              <button className="w-full mt-8 py-3 bg-indigo-500 text-white font-bold rounded-xl hover:bg-indigo-400 transition-colors">
                View Detailed Report
              </button>
            </section>

            <section className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm">
              <h3 className="font-bold text-gray-900 mb-6">Recommended for You</h3>
              <div className="space-y-4">
                {MOCK_JOBS.slice(2, 4).map(job => (
                  <div key={job.id} className="group cursor-pointer">
                    <div className="flex items-center space-x-3 mb-2">
                      <img src={job.companyLogo} className="w-8 h-8 rounded-lg" />
                      <div>
                        <p className="text-sm font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">{job.title}</p>
                        <p className="text-xs text-gray-400">{job.companyName}</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{job.salary}</span>
                      <ChevronRight size={14} />
                    </div>
                    <div className="mt-4 border-b border-gray-50"></div>
                  </div>
                ))}
              </div>
              <button className="w-full mt-6 text-sm font-bold text-indigo-600 hover:underline">Explore More Jobs</button>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateDashboard;
