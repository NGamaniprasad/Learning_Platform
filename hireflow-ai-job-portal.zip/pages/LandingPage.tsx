
import React from 'react';
import { Link } from 'react-router-dom';
import { Search, Sparkles, TrendingUp, ShieldCheck, Zap } from 'lucide-react';
import { MOCK_JOBS } from '../constants';

const LandingPage: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-6 overflow-hidden">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-indigo-100 rounded-full blur-3xl opacity-50"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-50"></div>
        
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center space-x-2 bg-indigo-50 text-indigo-700 px-4 py-1.5 rounded-full text-sm font-medium mb-8">
            <Sparkles size={16} />
            <span>AI-Powered Job Recommendations Now Live</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 mb-6 tracking-tight">
            Find your <span className="text-indigo-600">dream job</span> <br /> 10x faster with HireFlow.
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-10 leading-relaxed">
            The intelligent job portal that connects world-class talent with innovative companies.
            Upload your resume and let our AI do the matching.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4 mb-16">
            <Link to="/jobs" className="w-full sm:w-auto px-8 py-4 bg-indigo-600 text-white rounded-xl font-bold text-lg hover:bg-indigo-700 shadow-xl shadow-indigo-200 transition-all transform hover:-translate-y-1">
              Start Searching
            </Link>
            <button className="w-full sm:w-auto px-8 py-4 bg-white text-gray-900 border-2 border-gray-100 rounded-xl font-bold text-lg hover:bg-gray-50 transition-all flex items-center justify-center space-x-2">
              <span>Post a Job</span>
            </button>
          </div>

          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
            <img src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" alt="amazon" className="h-6" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg" alt="google" className="h-6" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/0/08/Netflix_2015_logo.svg" alt="netflix" className="h-6" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/4/44/Microsoft_logo.svg" alt="microsoft" className="h-6" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/b/b1/Apple_logo_black.svg" alt="apple" className="h-6" />
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="py-24 bg-gray-50 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Why top talent chooses HireFlow</h2>
            <p className="text-gray-600 max-w-xl mx-auto">We streamline the hiring process with cutting-edge technology and human-centric design.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center mb-6">
                <Zap size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Instant AI Analysis</h3>
              <p className="text-gray-600 leading-relaxed">
                Get immediate feedback on how your resume matches a job post and receive tips for improvement.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-6">
                <TrendingUp size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Smart Job Matches</h3>
              <p className="text-gray-600 leading-relaxed">
                Don't waste time scrolling. Our recommendation engine surfaces roles that actually fit your profile.
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center mb-6">
                <ShieldCheck size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Verified Companies</h3>
              <p className="text-gray-600 leading-relaxed">
                Every job post on our platform is from a vetted organization, ensuring a safe and legit experience.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Recent Jobs Section */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Featured Opportunities</h2>
            <p className="text-gray-600">New roles posted by industry leaders</p>
          </div>
          <Link to="/jobs" className="text-indigo-600 font-semibold hover:underline flex items-center">
            View all jobs
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {MOCK_JOBS.map(job => (
            <Link to={`/job/${job.id}`} key={job.id} className="group bg-white border border-gray-200 p-6 rounded-2xl hover:border-indigo-300 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center space-x-4 mb-4">
                <img src={job.companyLogo} alt={job.companyName} className="w-12 h-12 rounded-xl object-cover" />
                <div>
                  <h4 className="font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">{job.title}</h4>
                  <p className="text-sm text-gray-500">{job.companyName}</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 mb-4">
                <span className="text-xs font-medium px-2.5 py-1 bg-gray-100 text-gray-600 rounded-full">{job.location}</span>
                <span className="text-xs font-medium px-2.5 py-1 bg-indigo-50 text-indigo-600 rounded-full">{job.type}</span>
              </div>
              <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
                <span className="text-sm font-bold text-gray-900">{job.salary}</span>
                <span className="text-xs text-gray-400">{job.postedAt}</span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
