
import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { Plus, Users, LayoutDashboard, Briefcase, ChevronRight, BarChart3, Clock, Loader2 } from 'lucide-react';
import { MOCK_JOBS } from '../constants';
import { generateJobDescription } from '../geminiService';

interface Props {
  user: User | null;
}

const EmployerDashboard: React.FC<Props> = ({ user }) => {
  const [isPostingJob, setIsPostingJob] = useState(false);
  const [loadingAI, setLoadingAI] = useState(false);
  const [newJob, setNewJob] = useState({ title: '', location: '', type: 'Full-time', description: '' });

  if (!user || user.role !== UserRole.EMPLOYER) {
    return <div className="p-20 text-center">Unauthorized</div>;
  }

  const handleGenerateDesc = async () => {
    if (!newJob.title) return alert("Please enter a job title first.");
    setLoadingAI(true);
    try {
      const desc = await generateJobDescription(newJob.title, user.companyName || 'Our Company');
      setNewJob({ ...newJob, description: desc });
    } finally {
      setLoadingAI(false);
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between mb-10 gap-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-500 font-medium">Managing talent at <span className="text-indigo-600 font-bold">{user.companyName}</span></p>
          </div>
          <button 
            onClick={() => setIsPostingJob(true)}
            className="w-full md:w-auto px-6 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all flex items-center justify-center"
          >
            <Plus size={20} className="mr-2" />
            Post a New Job
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                <Briefcase size={20} />
              </div>
              <span className="text-xs font-bold text-emerald-600">+12%</span>
            </div>
            <p className="text-2xl font-black text-gray-900">8</p>
            <p className="text-sm text-gray-500">Active Jobs</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                <Users size={20} />
              </div>
              <span className="text-xs font-bold text-emerald-600">+5%</span>
            </div>
            <p className="text-2xl font-black text-gray-900">124</p>
            <p className="text-sm text-gray-500">Total Applicants</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                <Clock size={20} />
              </div>
            </div>
            <p className="text-2xl font-black text-gray-900">3</p>
            <p className="text-sm text-gray-500">Interviews Today</p>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                <BarChart3 size={20} />
              </div>
            </div>
            <p className="text-2xl font-black text-gray-900">84%</p>
            <p className="text-sm text-gray-500">Avg. Match Score</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-8 py-6 border-b border-gray-50 flex items-center justify-between">
              <h3 className="font-bold text-gray-900">Your Active Listings</h3>
              <button className="text-indigo-600 font-bold text-sm hover:underline">View All</button>
            </div>
            <div className="divide-y divide-gray-50">
              {MOCK_JOBS.filter(j => j.companyId === 'c1').map(job => (
                <div key={job.id} className="p-8 hover:bg-gray-50/50 transition-colors group cursor-pointer">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">{job.title}</h4>
                      <p className="text-sm text-gray-500">{job.location} • {job.type}</p>
                    </div>
                    <span className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold">Active</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center -space-x-2">
                      {[1, 2, 3].map(i => (
                        <img key={i} src={`https://picsum.photos/seed/${i + 10}/50/50`} className="w-8 h-8 rounded-full border-2 border-white" alt="applicant" />
                      ))}
                      <div className="w-8 h-8 rounded-full bg-gray-100 border-2 border-white flex items-center justify-center text-[10px] font-bold text-gray-500">+12</div>
                      <span className="ml-4 text-xs font-medium text-gray-400">new applications this week</span>
                    </div>
                    <ChevronRight size={18} className="text-gray-300" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm">
              <h3 className="font-bold text-gray-900 mb-6">Recent Applicants</h3>
              <div className="space-y-6">
                {[1, 2, 3].map(i => (
                  <div key={i} className="flex items-center space-x-4">
                    <img src={`https://picsum.photos/seed/${i + 50}/100/100`} className="w-10 h-10 rounded-xl" alt="applicant" />
                    <div className="flex-1">
                      <p className="text-sm font-bold text-gray-900">Applicant {i}</p>
                      <p className="text-xs text-gray-500">Applied for Senior Dev</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-black text-emerald-600">92% Match</p>
                    </div>
                  </div>
                ))}
              </div>
              <button className="w-full mt-8 py-3 border border-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-50 transition-colors text-sm">
                Review Queue
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* New Job Modal */}
      {isPostingJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-gray-900/40 backdrop-blur-sm">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden">
            <div className="p-8 max-h-[90vh] overflow-y-auto">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Create New Listing</h2>
              
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Job Title</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-2 bg-gray-50 border border-gray-100 rounded-xl outline-none" 
                      placeholder="e.g. Senior Product Designer"
                      value={newJob.title}
                      onChange={(e) => setNewJob({...newJob, title: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Location</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-2 bg-gray-50 border border-gray-100 rounded-xl outline-none" 
                      placeholder="e.g. Remote or San Francisco"
                      value={newJob.location}
                      onChange={(e) => setNewJob({...newJob, location: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-bold text-gray-700">Job Description</label>
                    <button 
                      onClick={handleGenerateDesc}
                      disabled={loadingAI}
                      className="text-xs font-bold text-indigo-600 flex items-center hover:underline disabled:opacity-50"
                    >
                      {loadingAI ? <Loader2 size={12} className="animate-spin mr-1" /> : <LayoutDashboard size={12} className="mr-1" />}
                      Generate with AI
                    </button>
                  </div>
                  <textarea 
                    rows={8} 
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none text-sm font-mono"
                    value={newJob.description}
                    onChange={(e) => setNewJob({...newJob, description: e.target.value})}
                    placeholder="Enter job details or use AI to generate a template..."
                  ></textarea>
                </div>

                <div className="flex space-x-4 pt-4">
                  <button 
                    onClick={() => setIsPostingJob(false)}
                    className="flex-1 py-3 border border-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-50"
                  >
                    Discard
                  </button>
                  <button className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700">
                    Publish Listing
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployerDashboard;
