
import React, { useState, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MapPin, Briefcase, Calendar, DollarSign, ArrowLeft, Send, Sparkles, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { MOCK_JOBS } from '../constants';
import { User, AIAnalysisResult } from '../types';
import { analyzeResume } from '../geminiService';

interface JobDetailProps {
  currentUser: User | null;
}

const JobDetail: React.FC<JobDetailProps> = ({ currentUser }) => {
  const { id } = useParams();
  const job = MOCK_JOBS.find(j => j.id === id);
  const [isApplying, setIsApplying] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AIAnalysisResult | null>(null);
  const [applied, setApplied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!job) return <div className="p-20 text-center">Job not found</div>;

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setAnalyzing(true);
    // Simulate reading file text (In a real app, we'd use a PDF parser)
    const mockResumeText = `
      John Doe - Frontend Engineer
      Skills: React, JavaScript, CSS, HTML, TypeScript, UI Design.
      Experience: 3 years at WebFlow working on dashboard components.
      Education: BS Computer Science.
    `;

    try {
      const result = await analyzeResume(mockResumeText, job.description + " " + job.requirements.join(" "));
      setAnalysisResult(result);
    } catch (error) {
      console.error("Analysis failed", error);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleApply = () => {
    setIsApplying(true);
    setTimeout(() => {
      setIsApplying(false);
      setApplied(true);
    }, 1500);
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8 px-6">
      <div className="max-w-4xl mx-auto">
        <Link to="/jobs" className="inline-flex items-center text-gray-500 hover:text-indigo-600 mb-6 font-medium transition-colors">
          <ArrowLeft size={18} className="mr-2" />
          Back to listings
        </Link>

        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
          {/* Header */}
          <div className="p-8 border-b border-gray-50 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center space-x-6">
              <img src={job.companyLogo} alt={job.companyName} className="w-20 h-20 rounded-2xl object-cover border border-gray-100" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{job.title}</h1>
                <div className="flex flex-wrap items-center gap-y-2 gap-x-6">
                  <span className="text-indigo-600 font-bold flex items-center"><Briefcase size={18} className="mr-2" /> {job.companyName}</span>
                  <span className="text-gray-500 flex items-center"><MapPin size={18} className="mr-2" /> {job.location}</span>
                </div>
              </div>
            </div>
            {!applied ? (
              <button 
                onClick={() => setIsApplying(true)}
                className="px-8 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all flex items-center justify-center"
              >
                Apply Now
                <Send size={18} className="ml-2" />
              </button>
            ) : (
              <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50 px-6 py-3 rounded-xl font-bold">
                <CheckCircle2 size={20} />
                <span>Application Sent</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-gray-50 bg-gray-50/30 p-4">
            <div className="p-4 text-center">
              <p className="text-xs text-gray-400 uppercase font-bold tracking-wider mb-1">Salary</p>
              <p className="font-bold text-gray-900">{job.salary}</p>
            </div>
            <div className="p-4 text-center">
              <p className="text-xs text-gray-400 uppercase font-bold tracking-wider mb-1">Job Type</p>
              <p className="font-bold text-gray-900">{job.type}</p>
            </div>
            <div className="p-4 text-center">
              <p className="text-xs text-gray-400 uppercase font-bold tracking-wider mb-1">Posted</p>
              <p className="font-bold text-gray-900">{job.postedAt}</p>
            </div>
            <div className="p-4 text-center">
              <p className="text-xs text-gray-400 uppercase font-bold tracking-wider mb-1">Applicants</p>
              <p className="font-bold text-gray-900">42</p>
            </div>
          </div>

          <div className="p-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Job Description</h3>
            <p className="text-gray-600 leading-relaxed mb-8">{job.description}</p>

            <h3 className="text-xl font-bold text-gray-900 mb-4">Requirements</h3>
            <ul className="space-y-3 mb-8">
              {job.requirements.map((req, idx) => (
                <li key={idx} className="flex items-start space-x-3 text-gray-600">
                  <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0"></div>
                  <span>{req}</span>
                </li>
              ))}
            </ul>

            <div className="bg-indigo-50/50 p-6 rounded-2xl border border-indigo-100">
              <h3 className="text-lg font-bold text-indigo-900 mb-2 flex items-center">
                <Sparkles size={20} className="mr-2 text-indigo-600" />
                AI Assistant
              </h3>
              <p className="text-indigo-800 text-sm mb-4">
                Want to know if you're a good fit? Upload your resume for an instant AI analysis and matching score.
              </p>
              
              {!analysisResult ? (
                <div className="flex flex-col items-center justify-center border-2 border-dashed border-indigo-200 rounded-xl p-8 bg-white transition-all">
                  {analyzing ? (
                    <div className="flex flex-col items-center space-y-4">
                      <Loader2 size={32} className="text-indigo-600 animate-spin" />
                      <p className="text-indigo-600 font-bold">Analyzing your resume...</p>
                    </div>
                  ) : (
                    <>
                      <input 
                        type="file" 
                        id="resume-upload" 
                        className="hidden" 
                        ref={fileInputRef}
                        onChange={handleFileUpload}
                      />
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 transition-colors"
                      >
                        Analyze My Resume
                      </button>
                    </>
                  )}
                </div>
              ) : (
                <div className="bg-white p-6 rounded-xl border border-indigo-100">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <span className="text-sm font-bold text-gray-500 uppercase">Match Score</span>
                      <p className={`text-4xl font-black ${analysisResult.matchScore > 70 ? 'text-emerald-600' : 'text-amber-600'}`}>
                        {analysisResult.matchScore}%
                      </p>
                    </div>
                    <button 
                      onClick={() => setAnalysisResult(null)}
                      className="text-xs text-indigo-600 font-bold hover:underline"
                    >
                      Reset
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <h4 className="font-bold text-emerald-700 text-sm mb-2 flex items-center">
                        <CheckCircle2 size={16} className="mr-1.5" /> Strengths
                      </h4>
                      <ul className="space-y-1">
                        {analysisResult.strengths.map((s, i) => <li key={i} className="text-xs text-gray-600">• {s}</li>)}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-bold text-amber-700 text-sm mb-2 flex items-center">
                        <AlertCircle size={16} className="mr-1.5" /> Gap Analysis
                      </h4>
                      <ul className="space-y-1">
                        {analysisResult.gaps.map((g, i) => <li key={i} className="text-xs text-gray-600">• {g}</li>)}
                      </ul>
                    </div>
                  </div>

                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-xs font-bold text-gray-400 uppercase mb-2">AI Feedback</p>
                    <p className="text-sm text-gray-700 leading-relaxed italic">"{analysisResult.feedback}"</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Application Modal */}
      {isApplying && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-gray-900/40 backdrop-blur-sm">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Finalize Application</h2>
              <p className="text-gray-500 mb-8">Applying to {job.title} at {job.companyName}</p>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Cover Letter (Optional)</label>
                  <textarea 
                    rows={4} 
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                    placeholder="Tell them why you're a great fit..."
                  ></textarea>
                </div>
                
                <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-xl flex items-center">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center mr-4 text-indigo-600">
                    <Briefcase size={20} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-bold text-gray-900">resume_v3_final.pdf</p>
                    <p className="text-xs text-gray-500">Last updated yesterday</p>
                  </div>
                  <button className="text-indigo-600 font-bold text-xs hover:underline">Change</button>
                </div>

                <div className="flex space-x-4">
                  <button 
                    onClick={() => setIsApplying(false)}
                    className="flex-1 py-3 border border-gray-200 text-gray-600 font-bold rounded-xl hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleApply}
                    className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center justify-center"
                  >
                    Submit
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobDetail;
