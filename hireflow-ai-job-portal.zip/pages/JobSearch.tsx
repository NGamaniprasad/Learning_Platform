
import React, { useState, useMemo } from 'react';
import { Search, Filter, MapPin, Briefcase, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { MOCK_JOBS, CATEGORIES, JOB_TYPES } from '../constants';

const JobSearch: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedType, setSelectedType] = useState('All');

  const filteredJobs = useMemo(() => {
    return MOCK_JOBS.filter(job => {
      const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            job.companyName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || job.category === selectedCategory;
      const matchesType = selectedType === 'All' || job.type === selectedType;
      return matchesSearch && matchesCategory && matchesType;
    });
  }, [searchTerm, selectedCategory, selectedType]);

  return (
    <div className="bg-gray-50 min-h-screen py-8 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="md:col-span-6 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input 
                type="text" 
                placeholder="Job title, keywords, or company..."
                className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="md:col-span-3">
              <select 
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
              >
                {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
              </select>
            </div>
            <div className="md:col-span-3">
              <button className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100">
                Search Jobs
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <div className="flex items-center space-x-2 mb-6">
                <Filter size={18} className="text-indigo-600" />
                <h3 className="font-bold text-gray-900">Job Filters</h3>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">Job Type</label>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-3 cursor-pointer">
                      <input 
                        type="radio" 
                        name="type" 
                        className="w-4 h-4 text-indigo-600 border-gray-300 focus:ring-indigo-500" 
                        checked={selectedType === 'All'}
                        onChange={() => setSelectedType('All')}
                      />
                      <span className="text-sm text-gray-600">All Types</span>
                    </label>
                    {JOB_TYPES.map(type => (
                      <label key={type} className="flex items-center space-x-3 cursor-pointer">
                        <input 
                          type="radio" 
                          name="type" 
                          className="w-4 h-4 text-indigo-600 border-gray-300 focus:ring-indigo-500" 
                          checked={selectedType === type}
                          onChange={() => setSelectedType(type)}
                        />
                        <span className="text-sm text-gray-600">{type}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">Salary Range</label>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded text-indigo-600" />
                      <span className="text-sm text-gray-600">$50k - $80k</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded text-indigo-600" />
                      <span className="text-sm text-gray-600">$80k - $120k</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded text-indigo-600" />
                      <span className="text-sm text-gray-600">$120k+</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Job List */}
          <div className="lg:col-span-3 space-y-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-gray-600 text-sm">Showing <span className="font-bold">{filteredJobs.length}</span> jobs</p>
              <div className="flex items-center text-sm">
                <span className="text-gray-500 mr-2">Sort by:</span>
                <select className="bg-transparent font-bold text-gray-900 focus:outline-none">
                  <option>Newest</option>
                  <option>Highest Salary</option>
                </select>
              </div>
            </div>

            {filteredJobs.length > 0 ? (
              filteredJobs.map(job => (
                <div key={job.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:border-indigo-200 transition-all flex flex-col md:flex-row items-start md:items-center justify-between group">
                  <div className="flex items-center space-x-5">
                    <div className="w-16 h-16 bg-gray-50 rounded-xl flex items-center justify-center p-2 border border-gray-100 overflow-hidden">
                      <img src={job.companyLogo} alt={job.companyName} className="max-w-full rounded-lg" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">{job.title}</h3>
                      <div className="flex flex-wrap items-center gap-y-1 gap-x-4 mt-1">
                        <span className="text-sm text-gray-600 flex items-center"><Briefcase size={14} className="mr-1.5" /> {job.companyName}</span>
                        <span className="text-sm text-gray-600 flex items-center"><MapPin size={14} className="mr-1.5" /> {job.location}</span>
                        <span className="text-sm text-indigo-600 font-medium">{job.type}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4 md:mt-0 flex items-center space-x-4 w-full md:w-auto">
                    <div className="text-right hidden md:block mr-4">
                      <p className="text-lg font-bold text-gray-900">{job.salary}</p>
                      <p className="text-xs text-gray-400">{job.postedAt}</p>
                    </div>
                    <Link 
                      to={`/job/${job.id}`}
                      className="flex-1 md:flex-none px-6 py-2.5 bg-indigo-50 text-indigo-600 font-bold rounded-xl hover:bg-indigo-600 hover:text-white transition-all flex items-center justify-center"
                    >
                      View Details
                      <ChevronRight size={16} className="ml-1" />
                    </Link>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-white p-12 rounded-2xl text-center">
                <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Search size={32} className="text-gray-300" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">No jobs found</h3>
                <p className="text-gray-500">Try adjusting your filters or search terms.</p>
                <button 
                  onClick={() => {setSearchTerm(''); setSelectedCategory('All'); setSelectedType('All');}}
                  className="mt-6 text-indigo-600 font-bold hover:underline"
                >
                  Clear all filters
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobSearch;
