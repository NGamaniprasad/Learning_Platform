
import React, { useState } from 'react';
import { HashRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { User, UserRole, Job } from './types';
import LandingPage from './pages/LandingPage';
import JobSearch from './pages/JobSearch';
import JobDetail from './pages/JobDetail';
import CandidateDashboard from './pages/CandidateDashboard';
import EmployerDashboard from './pages/EmployerDashboard';
import { Search, User as UserIcon, Briefcase, PlusCircle, LogOut } from 'lucide-react';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);

  const loginAsCandidate = () => {
    setUser({
      id: 'u1',
      name: 'Alex Johnson',
      email: 'alex@example.com',
      role: UserRole.CANDIDATE,
      avatar: 'https://picsum.photos/seed/alex/100/100',
      bio: 'Passionate Frontend Developer with 4 years of experience.'
    });
  };

  const loginAsEmployer = () => {
    setUser({
      id: 'e1',
      name: 'Sarah Smith',
      email: 'sarah@techvibe.com',
      role: UserRole.EMPLOYER,
      companyName: 'TechVibe',
      avatar: 'https://picsum.photos/seed/sarah/100/100'
    });
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <nav className="sticky top-0 z-50 glass shadow-sm px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <div className="bg-indigo-600 p-2 rounded-lg text-white">
              <Briefcase size={24} />
            </div>
            <span className="text-2xl font-bold text-gray-900 tracking-tight">HireFlow</span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <Link to="/jobs" className="text-gray-600 hover:text-indigo-600 font-medium transition-colors">Find Jobs</Link>
            <Link to="#" className="text-gray-600 hover:text-indigo-600 font-medium transition-colors">Companies</Link>
            <Link to="#" className="text-gray-600 hover:text-indigo-600 font-medium transition-colors">Resources</Link>
          </div>

          <div className="flex items-center space-x-4">
            {!user ? (
              <div className="flex space-x-3">
                <button 
                  onClick={loginAsCandidate}
                  className="px-4 py-2 text-indigo-600 font-semibold hover:bg-indigo-50 rounded-lg transition-all"
                >
                  Sign In
                </button>
                <button 
                  onClick={loginAsEmployer}
                  className="px-5 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 shadow-md hover:shadow-lg transition-all"
                >
                  Post a Job
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                {user.role === UserRole.EMPLOYER && (
                  <Link 
                    to="/employer" 
                    className="hidden sm:flex items-center space-x-1 text-indigo-600 hover:bg-indigo-50 px-3 py-2 rounded-md transition-colors"
                  >
                    <PlusCircle size={18} />
                    <span>Manage Jobs</span>
                  </Link>
                )}
                {user.role === UserRole.CANDIDATE && (
                  <Link 
                    to="/candidate" 
                    className="hidden sm:flex items-center space-x-1 text-indigo-600 hover:bg-indigo-50 px-3 py-2 rounded-md transition-colors"
                  >
                    <UserIcon size={18} />
                    <span>Dashboard</span>
                  </Link>
                )}
                <div className="flex items-center space-x-2 border-l pl-4 ml-4">
                  <img src={user.avatar} className="w-8 h-8 rounded-full border-2 border-indigo-200" alt="avatar" />
                  <span className="hidden lg:inline text-sm font-medium text-gray-700">{user.name}</span>
                  <button onClick={logout} title="Logout" className="text-gray-400 hover:text-red-500 transition-colors">
                    <LogOut size={18} />
                  </button>
                </div>
              </div>
            )}
          </div>
        </nav>

        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/jobs" element={<JobSearch />} />
            <Route path="/job/:id" element={<JobDetail currentUser={user} />} />
            <Route path="/candidate" element={<CandidateDashboard user={user} />} />
            <Route path="/employer" element={<EmployerDashboard user={user} />} />
          </Routes>
        </main>

        <footer className="bg-white border-t border-gray-100 py-12 px-6">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-1">
              <div className="flex items-center space-x-2 mb-4">
                <Briefcase className="text-indigo-600" size={24} />
                <span className="text-xl font-bold text-gray-900">HireFlow</span>
              </div>
              <p className="text-gray-500 text-sm">
                Empowering your career journey with AI-driven job matching and professional tools.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-gray-900">For Candidates</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><Link to="/jobs" className="hover:text-indigo-600">Browse Jobs</Link></li>
                <li><Link to="/candidate" className="hover:text-indigo-600">Resume Builder</Link></li>
                <li><Link to="#" className="hover:text-indigo-600">Job Alerts</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-gray-900">For Employers</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><Link to="#" className="hover:text-indigo-600">Post a Job</Link></li>
                <li><Link to="#" className="hover:text-indigo-600">Candidate Search</Link></li>
                <li><Link to="#" className="hover:text-indigo-600">Hiring Solutions</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-gray-900">Company</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><Link to="#" className="hover:text-indigo-600">About Us</Link></li>
                <li><Link to="#" className="hover:text-indigo-600">Careers</Link></li>
                <li><Link to="#" className="hover:text-indigo-600">Support</Link></li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center text-sm text-gray-400">
            <p>&copy; 2024 HireFlow. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-indigo-600">Privacy Policy</a>
              <a href="#" className="hover:text-indigo-600">Terms of Service</a>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
};

export default App;
