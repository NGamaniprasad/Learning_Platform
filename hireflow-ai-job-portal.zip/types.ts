
export enum UserRole {
  CANDIDATE = 'CANDIDATE',
  EMPLOYER = 'EMPLOYER'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  bio?: string;
  resumeUrl?: string;
  companyName?: string;
}

export interface Job {
  id: string;
  companyId: string;
  companyName: string;
  companyLogo: string;
  title: string;
  location: string;
  type: 'Full-time' | 'Part-time' | 'Contract' | 'Remote';
  salary: string;
  description: string;
  requirements: string[];
  postedAt: string;
  category: string;
}

export interface Application {
  id: string;
  jobId: string;
  candidateId: string;
  status: 'Pending' | 'Reviewing' | 'Interview' | 'Accepted' | 'Rejected';
  appliedAt: string;
}

export interface AIAnalysisResult {
  matchScore: number;
  strengths: string[];
  gaps: string[];
  feedback: string;
}
