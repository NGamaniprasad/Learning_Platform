
import { GoogleGenAI, Type } from "@google/genai";
import { Job, AIAnalysisResult } from "./types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeResume = async (resumeText: string, jobDescription: string): Promise<AIAnalysisResult> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `
      Analyze the following resume against the job description.
      
      JOB DESCRIPTION:
      ${jobDescription}
      
      RESUME CONTENT:
      ${resumeText}
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          matchScore: { type: Type.NUMBER, description: "A score from 0-100 indicating fit." },
          strengths: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Key matching skills found." },
          gaps: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Missing requirements or areas of improvement." },
          feedback: { type: Type.STRING, description: "Overall constructive feedback for the candidate." }
        },
        required: ["matchScore", "strengths", "gaps", "feedback"]
      }
    }
  });

  return JSON.parse(response.text || "{}") as AIAnalysisResult;
};

export const generateJobDescription = async (title: string, company: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Write a professional and engaging job description for a "${title}" position at "${company}". Include sections for Overview, Responsibilities, and Requirements.`
  });
  return response.text || "Failed to generate description.";
};
