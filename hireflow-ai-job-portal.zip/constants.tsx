
import React from 'react';
import { Job } from './types';

export const MOCK_JOBS: Job[] = [
  {
    id: '1',
    companyId: 'c1',
    companyName: 'TechVibe',
    companyLogo: 'https://picsum.photos/seed/tech/100/100',
    title: 'Senior Frontend Engineer',
    location: 'San Francisco, CA',
    type: 'Full-time',
    salary: '$140k - $180k',
    description: 'We are looking for a React expert to lead our dashboard revamp.',
    requirements: ['5+ years React', 'TypeScript', 'Tailwind CSS'],
    postedAt: '2 days ago',
    category: 'Engineering'
  },
  {
    id: '2',
    companyId: 'c2',
    companyName: 'Creatify',
    companyLogo: 'https://picsum.photos/seed/design/100/100',
    title: 'Product Designer',
    location: 'Remote',
    type: 'Contract',
    salary: '$80 - $120 / hr',
    description: 'Help us design the next generation of creative tools.',
    requirements: ['Figma', 'UI/UX', 'Prototyping'],
    postedAt: '1 week ago',
    category: 'Design'
  },
  {
    id: '3',
    companyId: 'c3',
    companyName: 'DataPulse',
    companyLogo: 'https://picsum.photos/seed/data/100/100',
    title: 'Data Scientist',
    location: 'New York, NY',
    type: 'Full-time',
    salary: '$130k - $160k',
    description: 'Build predictive models for financial forecasting.',
    requirements: ['Python', 'SQL', 'Machine Learning'],
    postedAt: '5 hours ago',
    category: 'Data Science'
  }
];

export const CATEGORIES = [
  'All',
  'Engineering',
  'Design',
  'Data Science',
  'Product',
  'Marketing',
  'Sales'
];

export const JOB_TYPES = [
  'Full-time',
  'Part-time',
  'Contract',
  'Remote'
];
